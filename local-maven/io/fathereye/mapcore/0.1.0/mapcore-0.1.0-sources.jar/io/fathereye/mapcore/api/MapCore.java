package io.fathereye.mapcore.api;

import io.fathereye.mapcore.internal.NoOpMapRenderer;

/**
 * Entry point and version constant for the mapcore library.
 */
public final class MapCore {

    /** Library version. Consumers pin to an exact value (no ranges). */
    public static final String VERSION = "0.1.0";

    /** Wire-protocol version for any data contracts that depend on this library. */
    public static final int CONTRACT_MAJOR = 0;
    public static final int CONTRACT_MINOR = 1;

    private MapCore() {}

    /**
     * Stub renderer — draws a dim background and one debug line. Replace with
     * the full renderer in milestone 12.
     */
    public static MapRenderer noOpRenderer() {
        return new NoOpMapRenderer();
    }
}
